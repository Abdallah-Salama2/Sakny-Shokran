import "./styles.css";

import React from "react";

export default function Listing() {
  return <div>Listing</div>;
}
