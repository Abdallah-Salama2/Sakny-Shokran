import "./styles.css";
import React from "react";

// Form to contact agent when buying house
export default function Contactform() {
  return <div>Contactform</div>;
}
